Files in this directory:

static_potential_3x2_m2_omega1_l1_mutualinfoansatz.txt: data file with run with final string break configuration as initial point.

static_potential_3x2_m2_omega1_l1_mutualinfoansatz_v2.txt: data file with run with 4 configurations vacuum for sites and all cases for gauge fields.
    Data saved: coupling "g", exat ground state "ed0", exact ground state eigenstate probabilities (ed_dict={bin str: probability}),
        VQE results, ground state with NFT optimizer and 10^4 shots "vqe0", standard deviation "std_dev", ground state eigenstate probabilities (vqe_dict={bin str: probability}, fidelity, optimal_point to be used with the circuit and Hamiltonian above.
        Data computed with electric basis and truncation l=1.

static_potential_fermions.ipynb: notebook with circuit, Hamiltonian and reading datafiles.